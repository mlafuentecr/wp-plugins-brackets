<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', 'root' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
// Enable WP_DEBUG mode
define( 'WP_DEBUG', true );

// Enable Debug logging to the /wp-content/debug.log file
define( 'WP_DEBUG_LOG', true );

// Disable display of errors and warnings
define( 'WP_DEBUG_DISPLAY', false );
@ini_set( 'display_errors', 0 );

// Use dev versions of core JS and CSS files (only needed if you are modifying these core files)
define( 'SCRIPT_DEBUG', true );




define('AUTH_KEY',         'wUTaLLbNHEvjgzLq63J/16tv+UA4jtlpOP43JhJz61TdJOAjd6iYRoguAwZD0vruy0rmfV1LKStdLmSy+gbU+g==');
define('SECURE_AUTH_KEY',  'NK1H+B2DtIhfLqeBdBjVG5uC4JwhQrMBPDm2LpndNrVUJmbWq4xM2rx5YI+rPzTWceT3Ww1KteAvlAw/RwHZ9Q==');
define('LOGGED_IN_KEY',    'rehSOYin3ZMFS+4s4A11CExcm+jqjtGKsWNbQQ2FoZxCzrmXf9tKgdezIGnQ03ZQdQJIG07iiS+S6gLokAxm0A==');
define('NONCE_KEY',        'OzaTjsHYL0dSpYR+72mufc82P28fV9w89kY0y/iu88VQKOQ9ztcV3s95gX0ls/o8r8YcE7ezbF3qswYHtqFetg==');
define('AUTH_SALT',        '78R4dvGjnqLkvTceMHG3v0uqD5dm4wCPEBGLCUSyqUAQB50YQrFfm4CD8+mF0fV1aD2nGouLErK5z49PeNZg+A==');
define('SECURE_AUTH_SALT', 'ayeVyMqmZU2Hqd1GGx4zY1fUpwIobOqNM5pAhcUmS2c+f6EHVW31dnXdEN3mUtN42I7oXCDEpObTn7YmJEyfEA==');
define('LOGGED_IN_SALT',   'MOXAnSCnZI/KmaBCeWSmv8xn32DSqRbReZsdaEplkFbH6ROr6n4oS4L3PQz8Dqu8WM7y9goKM/V30Vr36vBhYQ==');
define('NONCE_SALT',       'OBx+o1KI9Yt324q8M/5S9G+KyUtEqptMX19CDg/ykFpQyFhuRPtstVAO/AGeEemV7PuLpFLuu9+xYQfCodXxmQ==');
define( 'WP_ENVIRONMENT_TYPE', 'local' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
