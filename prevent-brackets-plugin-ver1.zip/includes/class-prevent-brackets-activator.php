<?php

/**
 * Fired during plugin activation
 *
 * @link       https://revmasters.com
 * @since      1.0.0
 *
 * @package    Prevent_Brackets
 * @subpackage Prevent_Brackets/includes
 */


class Prevent_Brackets_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */


	
	public static function activate() {
		
	
	}
	static function activate_tab_plugin() {
	
	}

	
}
